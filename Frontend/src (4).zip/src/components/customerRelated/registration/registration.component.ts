import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { HttpClient } from '@angular/common/http';
import { finalize } from 'rxjs/operators';
import { ProfileService } from '../../services/profile.service';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  user = {
    fullName: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    email: '',
    mobile: '',
    customerType: '',
    electricalSection: '',
    userId: '',
    consumerNumber: '',
    newPassword: '',
    confirmPassword: '',
  };

  errorMessage: string = '';
  isLoading: boolean = false;
  showUserIdModal: boolean = false;
  showErrorIdModal: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private http: HttpClient,
    private profileService: ProfileService
  ) {}

  copyUserId(): void {
    if (this.user.userId) {
      navigator.clipboard.writeText(this.user.userId);
      alert('User ID copied!');
    }
  }

  goToLogin(): void {
    this.showUserIdModal = false;
    this.router.navigate(['/login']);
  }

  notNow(): void {
    this.showUserIdModal = false;
    this.router.navigate(['/home']);
  }

  registerAgain(): void {
    this.router.navigate(['/register']);
  }

  registerUser(): void {
    this.errorMessage = '';
    this.isLoading = true;

    // Ensure consumerNumber exists
    const consumer = (this.user.consumerNumber || '').trim();
    if (!consumer) {
      this.isLoading = false;
      this.errorMessage = 'Consumer number is required to register.';
      this.showErrorIdModal=true;
      return;
    }

    // Generate userId (same scheme used elsewhere)
    this.user.userId = 'u-' + consumer;

    // Build payload aligned with ProfileComponent (exclude confirmPassword)
    const payload: any = {
      fullName: this.user.fullName,
      address: this.user.address,
      city: this.user.city,
      state: this.user.state,
      pincode: this.user.pincode,
      email: this.user.email,
      mobile: this.user.mobile,
      customerType: this.user.customerType,
      electricalSection: this.user.electricalSection,
      userId: this.user.userId,
      consumerNumber: this.user.consumerNumber
    };

    // If the form provides a password field to set on registration, map it to newPassword
    // (ProfileComponent uses newPassword when updating password)
    if (this.user.newPassword) {
      payload.newPassword = this.user.newPassword;
      // do not send confirmPassword to backend unless backend expects it;
      // profile component sends confirmPassword only when newPassword present — replicate that
      payload.confirmPassword = this.user.confirmPassword ?? '';
    }

    // Call profileService using the (userId, payload) signature used in ProfileComponent
    this.profileService.updateProfile(this.user.userId, payload)
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe({
        next: () => {
          // show modal with generated userId on success
          this.showUserIdModal = true;
          this.showErrorIdModal=false;
        },
        error: (err) => {
          console.error('Registration/update error:', err);
          this.showUserIdModal = false;
          this.showErrorIdModal=true;
          if (err?.status === 409) {
            this.errorMessage = err?.error?.message || 'User already exists.';
          } else if (err?.status === 0) {
            this.errorMessage = 'Cannot connect to server. Please try again later.';
          } else {
            this.errorMessage = err?.error?.message || 'Registration failed.';
          }
        }
      });
  }

  fetchUserDetails(): void {
    this.errorMessage = '';

    const consumerId = (this.user.consumerNumber || '').trim();
    if (!consumerId) {
      this.errorMessage = 'Please provide a consumer number to fetch details.';
      return;
    }

    this.isLoading = true;

    // <-- CHANGE THIS URL to your real backend endpoint as needed -->
    const url = `http://localhost:8085/api/register/getbyid/${'u-' + encodeURIComponent(consumerId)}`;

    this.http.get<any>(url).pipe(
      finalize(() => { this.isLoading = false; })
    ).subscribe({
      next: (res) => {
        if (!res || typeof res !== 'object') {
          this.errorMessage = 'Invalid response from server.';
          return;
        }

        // Map response fields into the form's user object (safe mapping)
        this.user.fullName = res.fullName ?? this.user.fullName;
        this.user.address = res.address ?? this.user.address;
        this.user.city = res.city ?? this.user.city;
        this.user.state = res.state ?? this.user.state;
        this.user.pincode = res.pincode ?? this.user.pincode;
        this.user.email = res.email ?? this.user.email;
        this.user.mobile = res.mobile ?? this.user.mobile;
        this.user.customerType = res.customerType ?? this.user.customerType;
        this.user.electricalSection = res.electricalSection ?? this.user.electricalSection;
        this.user.userId = res.userId ?? this.user.userId;

        // Map backend newPassword/confirmPassword into password fields if provided
        if (res.newPassword) {
          this.user.newPassword = res.newPassword;
        }
        if (res.confirmPassword) {
          this.user.confirmPassword = res.confirmPassword;
        }

        // Clear any previous error
        this.errorMessage = '';
      },
      error: (err) => {
        console.error('Error fetching user details:', err);
        if (err?.status === 404) {
          this.errorMessage = 'No records found for this consumer number.';
        } else if (err?.status === 0) {
          this.errorMessage = 'Cannot connect to server. Please try again later.';
        } else {
          this.errorMessage = err?.error?.message || 'Failed to fetch user details.';
        }
      }
    });
  }
}