import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  user = {
    consumerNumber: '',
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    pincode: '',
    city: '',
    state: '',
    mobile: '',
    customerType: '',
    electricalSection: '',
    userId: '',
    address: '',
  };

  passMessage: string = '';
  errorMessage: string = '';
  passwordMismatch: boolean = false;
  isLoading: boolean = false; // ✅ added for button loading state
  showUserIdModal: boolean = false;
  showDuplicateErrorModal: boolean = false;


  cities: string[] = [];

  states = [
    { name: 'Andhra Pradesh', cities: ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Tirupati', 'Rajahmundry', 'Kadapa', 'Anantapur', 'Eluru'] },
    { name: 'Arunachal Pradesh', cities: ['Itanagar', 'Naharlagun', 'Tawang', 'Roing', 'Pasighat', 'Ziro', 'Bomdila', 'Tezu', 'Aalo', 'Namsai'] },
    { name: 'Assam', cities: ['Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat', 'Tezpur', 'Nagaon', 'Tinsukia', 'Sivasagar', 'Karimganj', 'Goalpara'] },
    { name: 'Bihar', cities: ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Purnea', 'Darbhanga', 'Arrah', 'Begusarai', 'Katihar', 'Munger'] },
    { name: 'Chhattisgarh', cities: ['Raipur', 'Bhilai', 'Bilaspur', 'Korba', 'Durg', 'Rajnandgaon', 'Jagdalpur', 'Raigarh', 'Ambikapur', 'Mahasamund'] },
    { name: 'Goa', cities: ['Panaji', 'Margao', 'Vasco da Gama', 'Mapusa', 'Ponda', 'Bicholim', 'Curchorem', 'Sanquelim', 'Valpoi', 'Cuncolim'] },
    { name: 'Gujarat', cities: ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Gandhinagar', 'Junagadh', 'Anand', 'Navsari'] },
    { name: 'Haryana', cities: ['Gurugram', 'Faridabad', 'Panipat', 'Ambala', 'Hisar', 'Karnal', 'Yamunanagar', 'Rohtak', 'Sirsa', 'Kurukshetra'] },
    { name: 'Himachal Pradesh', cities: ['Shimla', 'Dharamshala', 'Mandi', 'Solan', 'Kangra', 'Bilaspur', 'Una', 'Hamirpur', 'Chamba', 'Kullu'] },
    { name: 'Jharkhand', cities: ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro', 'Hazaribagh', 'Deoghar', 'Giridih', 'Ramgarh', 'Phusro', 'Jhumri Telaiya'] },
    { name: 'Karnataka', cities: ['Bengaluru', 'Mysuru', 'Mangaluru', 'Hubballi', 'Belagavi', 'Kalaburagi', 'Davangere', 'Shivamogga', 'Ballari', 'Udupi'] },
    { name: 'Kerala', cities: ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam', 'Alappuzha', 'Palakkad', 'Malappuram', 'Kannur', 'Kottayam'] },
    { name: 'Madhya Pradesh', cities: ['Indore', 'Bhopal', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna', 'Ratlam', 'Rewa'] },
    { name: 'Maharashtra', cities: ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Thane', 'Aurangabad', 'Solapur', 'Amravati', 'Kolhapur', 'Sangli'] },
    { name: 'Manipur', cities: ['Imphal', 'Thoubal', 'Bishnupur', 'Churachandpur', 'Senapati', 'Ukhrul', 'Kakching', 'Tamenglong', 'Jiribam', 'Moreh'] },
    { name: 'Meghalaya', cities: ['Shillong', 'Tura', 'Nongpoh', 'Jowai', 'Baghmara', 'Williamnagar', 'Mairang', 'Resubelpara', 'Khliehriat', 'Nongstoin'] },
    { name: 'Mizoram', cities: ['Aizawl', 'Lunglei', 'Saiha', 'Serchhip', 'Kolasib', 'Champhai', 'Mamit', 'Lawngtlai', 'Bairabi', 'Hnahthial'] },
    { name: 'Nagaland', cities: ['Kohima', 'Dimapur', 'Mokokchung', 'Tuensang', 'Wokha', 'Zunheboto', 'Mon', 'Phek', 'Kiphire', 'Longleng'] },
    { name: 'Odisha', cities: ['Bhubaneswar', 'Cuttack', 'Rourkela', 'Berhampur', 'Sambalpur', 'Balasore', 'Puri', 'Jeypore', 'Baripada', 'Jharsuguda'] },
    { name: 'Punjab', cities: ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Mohali', 'Pathankot', 'Hoshiarpur', 'Moga', 'Firozpur'] },
    { name: 'Rajasthan', cities: ['Jaipur', 'Jodhpur', 'Kota', 'Udaipur', 'Ajmer', 'Bikaner', 'Alwar', 'Sikar', 'Bhilwara', 'Pali'] },
    { name: 'Sikkim', cities: ['Gangtok', 'Namchi', 'Mangan', 'Geyzing', 'Singtam', 'Rangpo', 'Jorethang', 'Ravangla', 'Soreng', 'Yuksom'] },
    { name: 'Tamil Nadu', cities: ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Tirunelveli', 'Salem', 'Vellore', 'Erode', 'Dindigul', 'Thoothukudi'] },
    { name: 'Telangana', cities: ['Hyderabad', 'Warangal', 'Nizamabad', 'Khammam', 'Karimnagar', 'Ramagundam', 'Mahbubnagar', 'Adilabad', 'Suryapet', 'Miryalaguda'] },
    { name: 'Tripura', cities: ['Agartala', 'Udaipur', 'Dharmanagar', 'Kailasahar', 'Belonia', 'Ambassa', 'Khowai', 'Sonamura', 'Ranirbazar', 'Kamalpur'] },
    { name: 'Uttar Pradesh', cities: ['Lucknow', 'Kanpur', 'Varanasi', 'Prayagraj', 'Agra', 'Ghaziabad', 'Noida', 'Meerut', 'Bareilly', 'Aligarh'] },
    { name: 'Uttarakhand', cities: ['Dehradun', 'Haridwar', 'Roorkee', 'Haldwani', 'Rishikesh', 'Kashipur', 'Rudrapur', 'Nainital', 'Pithoragarh', 'Mussoorie'] },
    { name: 'West Bengal', cities: ['Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri', 'Bardhaman', 'Malda', 'Kharagpur', 'Berhampore', 'Haldia'] },

    // -------------------- UNION TERRITORIES ---------------------

    { name: 'Andaman and Nicobar Islands', cities: ['Port Blair', 'Rangat', 'Diglipur', 'Mayabunder', 'Hut Bay', 'Neil Island', 'Havelock', 'Car Nicobar', 'Campbell Bay', 'Bambooflat'] },
    { name: 'Chandigarh', cities: ['Chandigarh', 'Manimajra', 'Sector 17', 'Sector 22', 'Sector 43', 'Dhanas', 'Burail', 'Sarangpur', 'Maloya', 'Khuda Lahora'] },
    { name: 'Dadra and Nagar Haveli and Daman and Diu', cities: ['Silvassa', 'Daman', 'Diu', 'Naroli', 'Samarvarni', 'Varkund', 'Kadaiya', 'Athola', 'Kachigam', 'Moti Daman'] },
    { name: 'Delhi', cities: ['New Delhi', 'Dwarka', 'Rohini', 'Saket', 'Karol Bagh', 'Vasant Kunj', 'Lajpat Nagar', 'Mayur Vihar', 'Connaught Place', 'Pitampura'] },
    { name: 'Jammu and Kashmir', cities: ['Srinagar', 'Jammu', 'Udhampur', 'Anantnag', 'Baramulla', 'Kathua', 'Sopore', 'Kupwara', 'Rajouri', 'Poonch'] },
    { name: 'Ladakh', cities: ['Leh', 'Kargil', 'Diskit', 'Padum', 'Nubra Valley', 'Shey', 'Choglamsar', 'Sakti', 'Hemis', 'Turtuk'] },
    { name: 'Lakshadweep', cities: ['Kavaratti', 'Agatti', 'Minicoy', 'Amini', 'Kadmat', 'Kalpeni', 'Andrott', 'Chetlat', 'Bitra', 'Kiltan'] },
    { name: 'Puducherry', cities: ['Puducherry', 'Karaikal', 'Mahe', 'Yanam', 'Ozhukarai', 'Villiyanur', 'Bahour', 'Mangalam', 'Kottucherry', 'T.R. Pattinam'] }
  ];

  constructor(private authService: AuthService, private router: Router, private http: HttpClient) { }

  onStateChange(): void {
    const selected = this.states.find(s => s.name === this.user.state);
    this.cities = selected ? selected.cities : [];
    this.user.city = '';
  }

  copyUserId(): void {
    navigator.clipboard.writeText(this.user.userId);
    window.alert("User ID copied to clipboard!");
  }

  goToLogin(): void {
    this.showUserIdModal = false;
    this.router.navigate(['/login']);
  }


  notNow(): void {
    this.showUserIdModal = false;
    this.router.navigate(['/home']);
  }
  registerAgain(): void {
    this.router.navigate(['/register']);
  }


  fetchLocationByPincode(): void {
    const pincode = this.user.pincode;
    if (!pincode || pincode.length !== 6) return;

    this.http.get<any[]>(`https://api.postalpincode.in/pincode/${pincode}`).subscribe({
      next: (res) => {
        const info = res[0];
        if (info.Status === 'Success') {
          const postOffice = info.PostOffice[0];

          // Set state & city from pincode API
          this.user.state = postOffice.State;
          this.user.city = postOffice.District;

          // Update cities based on the detected state
          const matchState = this.states.find(s => s.name === this.user.state);
          this.cities = matchState ? [...matchState.cities] : [];

          // If city from API is not in the list, add it
          if (!this.cities.includes(this.user.city)) {
            this.cities.push(this.user.city);
          }
        }
      },
      error: (err) => console.error('Error fetching location', err)
    });
  }


  /** ✅ Real-time password match check */
  validatePasswords(): void {
    this.passwordMismatch = this.user.password !== this.user.confirmPassword;
  }

  /** ✅ Utility validators */
  private isOnlyZeros(value: string): boolean {
    return /^0+$/.test(value.trim());
  }

  private isStrongPassword(value: string): boolean {
    // At least 1 uppercase, 1 lowercase, 1 number, 1 special character, and min 6 chars
    const strongPasswordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;
    return strongPasswordRegex.test(value.trim());
  }


  private isValidName(value: string): boolean {
    return /^[A-Za-z ]+$/.test(value.trim());
  }

  private isValidEmail(value: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
  }

  private isValidConsumerNumber(value: string): boolean {
    return /^[1-9][0-9]{12}$/.test(value.trim());
  }

  private isValidMobile(value: string): boolean {
    return /^(?!([0-9])\1{9})[6-9][0-9]{9}$/.test(value.trim());
  }

  /** ✅ Address validation (no zeros, not numeric-only, minimum 5 chars) */
  private isValidAddress(value: string): boolean {
    if (!value || value.trim().length < 5) return false;
    if (/^0+$/.test(value.trim())) return false;
    if (/^[0-9\s]+$/.test(value.trim())) return false;
    return /^[a-zA-Z0-9\s,./#'-]+$/.test(value.trim());
  }

  /** ✅ Registration logic with validations */
  registerUser(): void {
    this.errorMessage = '';
    this.isLoading = true;

    // Empty field check
    if (!this.user.fullName || !this.user.email || !this.user.password || !this.user.confirmPassword) {
      this.errorMessage = 'Please fill in all required fields.';
      this.isLoading = false;
      return;
    }

    // Field-level validations
    if (!this.isValidName(this.user.fullName)) {
      this.errorMessage = 'Full Name must contain only alphabets.';
      this.isLoading = false;
      return;
    }

    if (!this.isValidEmail(this.user.email)) {
      this.errorMessage = 'Please enter a valid email address.';
      this.isLoading = false;
      return;
    }

    if (!this.isValidConsumerNumber(this.user.consumerNumber)) {
      this.errorMessage = 'Consumer number must be exactly 13 digits and cannot start with 0.';
      this.isLoading = false;
      return;
    }

    if (!this.isValidMobile(this.user.mobile)) {
      this.errorMessage = 'Enter a valid 10-digit phone number (not repetitive).';
      this.isLoading = false;
      return;
    }

    if (this.isOnlyZeros(this.user.pincode) || this.isOnlyZeros(this.user.consumerNumber)) {
      this.errorMessage = 'Fields cannot contain only zeros.';
      this.isLoading = false;
      return;
    }

    if (!this.isValidAddress(this.user.address)) {
      this.errorMessage = 'Please enter a valid address (cannot be only zeros, numeric, or too short).';
      this.isLoading = false;
      return;
    }

    if (!this.isStrongPassword(this.user.password)) {
      this.errorMessage =
        'Password must contain uppercase, lowercase, number, special character, and be at least 6 characters.';
      this.isLoading = false;
      return;
    }


    if (this.user.password !== this.user.confirmPassword) {
      this.errorMessage = 'Passwords do not match.';
      this.isLoading = false;
      return;
    }

    // Generate user ID
    this.user.userId = 'u-' + this.user.consumerNumber;

    // ✅ API call
    this.authService.register(this.user).subscribe({



      next: () => {
        this.isLoading = false;
        this.showUserIdModal = true;
      },
      error: (err) => {
        console.error('Registration failed:', err);
        this.isLoading = false;

        // ✅ Improved backend-aware error handling
        if (err.status === 409 || err.status === 400 || err.error?.message?.includes('CONSUMER_NUMBER')) {
          this.errorMessage = err.error?.message || 'Consumer number already exists.';
        } else if (err.status === 0) {
          this.errorMessage = 'Cannot connect to server. Please try again later.';
        } else if (err.error?.message?.includes('Email')) {
          this.errorMessage = 'Email already exists.';
        } else {
          this.errorMessage = 'Registration failed. Please try again.';

        }
      }
    });
  }
}
